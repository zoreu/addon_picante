try:
    from libs.browser import request #kodi
except:
    from browser import request # vscode
from bs4 import BeautifulSoup
import re
try:
    from urllib.parse import urlparse, parse_qs #python 3
except ImportError:    
    from urlparse import urlparse, parse_qs #python 2


homepage = 'https://pt.pornhub.com'
search_page = 'https://pt.pornhub.com/video/search?search='

def index():
    html = request.get_url(homepage + '/')
    soup = BeautifulSoup(html, 'html.parser')
    a1 = soup.find("a", {"data-mixpanel-listing": "Videos Menu Sidebar Hottest"})
    a2 = soup.find("a", {"data-mixpanel-listing": "Videos Menu Sidebar Most Viewed"})
    a3 = soup.find("a", {"data-mixpanel-listing": "Videos Menu Sidebar Recommended"})
    a4 = soup.find("a", {"data-mixpanel-listing": "Videos Menu Sidebar Top Rated"})
    a5 = soup.find("a", {"data-mixpanel-listing": "Videos Menu Sidebar Popular Homemade"})
    lista_index = []
    mais_excitantes = ('Mais Excitantes', homepage + a1.get('href') if a1.get('href') else '')
    mais_vistos = ('Mais Vistos', homepage + a2.get('href') if a2.get('href') else '')
    recomendados = ('Recomendados', homepage + a3.get('href') if a3.get('href') else '')
    mais_votados = ('Mais Votados', homepage + a4.get('href') if a4.get('href') else '')
    caseiros_populares = ('Caseiros Populares', homepage + a5.get('href') if a5.get('href') else '')
    lista_index.append(recomendados)
    lista_index.append(mais_excitantes)
    lista_index.append(mais_vistos)
    lista_index.append(mais_votados)
    lista_index.append(caseiros_populares)
    return lista_index

def index_page(url):
    html = request.get_url(url)
    soup = BeautifulSoup(html, 'html.parser')
    divs = soup.find_all("div", {"class": "phimage"})
    lista_pagina = []
    if divs:
        for i in divs:
            href = homepage + i.find("a", class_=re.compile("^fade")).get('href')
            name = i.find("a", class_=re.compile("^fade")).get('title')
            img = i.find("img").get('data-image') if i.find("img").get('data-image') else i.find("img").get('data-mediumthumb') 
            lista_pagina.append((name,img,href))
    try:
        next = soup.find("li", {"class": "page_next"}).find("a").get('href')
        if next:
            next_url = homepage + next
        else:
            next_url = False
    except:
        next_url = False
    return lista_pagina, next_url

def categorias():
    url = homepage +'/categories'
    html = request.get_url(url)
    soup = BeautifulSoup(html, 'html.parser')
    ul = soup.find("ul", {"class": "catHeaderSubMenu"})    
    a_list = ul.find_all("a", {"class": "js-mixpanel"})
    lista_categorias = []
    if a_list:
        for i in a_list:
            name = i.find("strong").string
            href = homepage + i.get('href') if i.get('href') else ''
            img = i.find("img").get('data-image') if i.find("img").get('data-image') else ''
            lista_categorias.append((name,href,img))
    return lista_categorias